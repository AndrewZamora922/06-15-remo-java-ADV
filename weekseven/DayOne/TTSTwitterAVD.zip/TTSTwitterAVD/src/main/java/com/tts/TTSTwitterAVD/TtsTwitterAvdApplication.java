package com.tts.TTSTwitterAVD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TtsTwitterAvdApplication {

	public static void main(String[] args) {
		SpringApplication.run(TtsTwitterAvdApplication.class, args);
	}

}
